# Convex-hulls
This is a shared repository between me and Ghada to work on the Convex Hulls problem under the INF421 course.
further details on this project are to be uploaded as we make progress

# the structure : 
Class Main, where the code is to be executed.

Class Dataset, where we generate the 4 sets of data

Class canvas and display are to generate the graphs

Class Point2D and Points2D are to generate the points with proper methods

Class sweeping is to implement the Andrew's montone chain algorithm

Class Main_Algo, where we implement the Divide and Conquer algorithm

Class sweeping, where we implement the sweeping algorithm

Class Segment, where we generate a segment linking 2 points.

Class H_points2D, where we generate points with Hashmap data structure, this was used to conduct tests regarding the runtime of simple actions like remove.
